database name : webb
table name : af
table columns : id , username , password , per 


note : if the website is not orgnized , try zoomout 80% .. 