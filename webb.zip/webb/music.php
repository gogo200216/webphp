<head>
<link rel="stylesheet" type="text/css"
    href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.1.3/assets/owl.carousel.min.css" />

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:400,700|Roboto:400,700&display=swap" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
</head>
<section class="portfolio_section">
    <div class="container">
      <div class="custom_heading-container">
      <br>                <br>        <br>        <br>        <br>  
      <br>  
      <h2>
          Eminem
        </h2>
        <hr>
        <a href="out.php"> signout </a>

      </div>
      <p>
      If you don't know who the infamous Marshal Mathers is and his impact on hip hip, then you are either too young or are not from this planet. Eminem has had one of the most impressive career runs in hip hop history, selling millions of records, and winning countless accolades, all while pissing off the world.
      </p>
      <div class="layout_padding2-top">
        <div class="row">
          <div class="col-md-4">
            <div class="img-box">
              <img src="th2.jpg" alt="">
              <a href="https://www.youtube.com/watch?v=RjrA-slMoZ4">
                <img src="logo.jpg" alt="">
              </a>
            </div>
          </div>
          <div class="col-md-4">
            <div class="img-box">
              <img src="th1.jpg" alt="">
              <a href="https://www.youtube.com/watch?v=RHQC4fAhcbU">
                <img src="logo.jpg" alt="">
              </a>
            </div>
          </div>
          <div class="col-md-4">
            <div class="img-box">
              <img src="th3.jpg" alt="">
              <a href="https://www.youtube.com/watch?v=uelHwf8o7_U">
                <img src="logo.jpg" alt="">
              </a>
            </div>
          </div>
          <div class="col-md-4">
            <div class="img-box">
              <img src="th4.jpg" alt="">
              <a href="https://www.youtube.com/watch?v=XbGs_qK2PQA">
                <img src="logo.jpg" alt="">
              </a>
            </div>
          </div>
          <div class="col-md-4">
            <div class="img-box">
              <img src="th5.jpg" alt="">
              <a href="https://www.youtube.com/watch?v=S9bCLPwzSC0">
                <img src="logo.jpg" alt="">
              </a>
            </div>
          </div>
          <div class="col-md-4">
            <div class="img-box">
              <img src="th6.jpg" alt="">
              <a href="https://www.youtube.com/watch?v=eJO5HU_7_1w">
                <img src="logo.jpg" alt="">
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
